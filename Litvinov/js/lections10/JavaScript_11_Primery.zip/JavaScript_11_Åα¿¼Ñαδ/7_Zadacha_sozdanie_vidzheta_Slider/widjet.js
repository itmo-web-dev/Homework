;(function(){
	
	window.Slider = MySlider;
	
	function MySlider(el, objSetting){
		
	}	
}());