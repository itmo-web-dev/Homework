;(function(){
	window.TaskManager = function(el){
				
	}
	
	
}())