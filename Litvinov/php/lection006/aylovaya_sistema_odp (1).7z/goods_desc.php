<?php
var_dump($_GET);

$id = $_GET['id'];

var_dump($id);