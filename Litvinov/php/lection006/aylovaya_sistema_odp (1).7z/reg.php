<!DOCTYPE HTML>
<html lang="en">
<head>
    <title>Title</title>
    <meta charset="utf-8"> 
</head>
<body>
	<form method="post" action="add_user.php">
		<label for="login">Login</label>
		<input name="login" id="login" type="text">

		<label for="pwd">Password</label>
		<input name="pwd" id="pwd" type="password">

		<label for="check">Chekiboxi</label>;
		<input name="check" id="check" type="checkbox">

		<button id="sbm" type="submit">Отправить</button>
	</form>

</body>
</html>
