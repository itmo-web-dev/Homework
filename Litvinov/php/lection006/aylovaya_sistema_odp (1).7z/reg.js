(function)() {
	
	function valid(event) {
		console.log('ok');
		//event.
	}

	var sbm = document.getElementById("sbm");
	sbm.addEventListener('submit', valid);

}());
